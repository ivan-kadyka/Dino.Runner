To start application you can run any local server.
For example: python3 -m http.server